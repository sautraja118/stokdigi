import type { Config } from 'tailwindcss'
const config: Config = { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { navy:'#07102f', purple:'#7c3aed' } } }, plugins: [] }
export default config
