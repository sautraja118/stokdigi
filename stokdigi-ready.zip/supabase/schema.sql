create extension if not exists "uuid-ossp";

create table if not exists profiles (id uuid primary key references auth.users(id) on delete cascade, full_name text, phone text, role text default 'customer', created_at timestamp with time zone default now());
create table if not exists categories (id uuid primary key default uuid_generate_v4(), name text not null, slug text unique not null, icon text, created_at timestamp with time zone default now());
create table if not exists products (id uuid primary key default uuid_generate_v4(), category_id uuid references categories(id) on delete set null, name text not null, slug text unique not null, price numeric not null default 0, discount_price numeric, stock integer default 0, description text, benefits text, instructions text, image_url text, is_active boolean default true, is_popular boolean default false, is_new boolean default false, is_promo boolean default false, created_at timestamp with time zone default now());
create table if not exists orders (id uuid primary key default uuid_generate_v4(), invoice_number text unique not null, user_id uuid references auth.users(id) on delete set null, customer_name text not null, customer_email text not null, customer_phone text not null, total_amount numeric default 0, payment_method text, payment_proof_url text, status text default 'pending', buyer_note text, admin_note text, digital_delivery text, created_at timestamp with time zone default now());
create table if not exists order_items (id uuid primary key default uuid_generate_v4(), order_id uuid references orders(id) on delete cascade, product_id uuid references products(id) on delete set null, product_name text, quantity integer default 1, price numeric default 0, subtotal numeric default 0);
create table if not exists banners (id uuid primary key default uuid_generate_v4(), title text, subtitle text, image_url text, button_text text, button_link text, is_active boolean default true, created_at timestamp with time zone default now());
create table if not exists testimonials (id uuid primary key default uuid_generate_v4(), name text, message text, rating integer default 5, is_active boolean default true, created_at timestamp with time zone default now());
create table if not exists settings (id uuid primary key default uuid_generate_v4(), site_name text, logo_url text, whatsapp text, email text, instagram text, tiktok text, telegram text, bank_info text, qris_url text);


create or replace function public.handle_new_user() returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles(id, full_name, role) values (new.id, new.email, 'customer') on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table profiles enable row level security;alter table categories enable row level security;alter table products enable row level security;alter table orders enable row level security;alter table order_items enable row level security;alter table banners enable row level security;alter table testimonials enable row level security;alter table settings enable row level security;

create or replace function is_admin() returns boolean language sql security definer as $$ select exists(select 1 from profiles where id=auth.uid() and role='admin') $$;

create policy "public read categories" on categories for select using (true);
create policy "public read active products" on products for select using (is_active=true or is_admin());
create policy "public read banners" on banners for select using (is_active=true or is_admin());
create policy "public read testimonials" on testimonials for select using (is_active=true or is_admin());
create policy "public read settings" on settings for select using (true);

create policy "profile self read" on profiles for select using (id=auth.uid() or is_admin());
create policy "profile self update" on profiles for update using (id=auth.uid() or is_admin());
create policy "order insert public" on orders for insert with check (true);
create policy "order item insert public" on order_items for insert with check (true);
create policy "order read owner" on orders for select using (customer_email=(select email from auth.users where id=auth.uid()) or user_id=auth.uid() or is_admin());
create policy "order items read owner" on order_items for select using (exists(select 1 from orders o where o.id=order_id and (o.customer_email=(select email from auth.users where id=auth.uid()) or o.user_id=auth.uid() or is_admin())));

create policy "admin all categories" on categories for all using (is_admin()) with check (is_admin());
create policy "admin all products" on products for all using (is_admin()) with check (is_admin());
create policy "admin all orders" on orders for all using (is_admin()) with check (is_admin());
create policy "admin all order_items" on order_items for all using (is_admin()) with check (is_admin());
create policy "admin all banners" on banners for all using (is_admin()) with check (is_admin());
create policy "admin all testimonials" on testimonials for all using (is_admin()) with check (is_admin());
create policy "admin all settings" on settings for all using (is_admin()) with check (is_admin());

insert into categories(name,slug,icon) values ('Canva Team','canva-team','🎨'),('AI Tools','ai-tools','🤖'),('Streaming','streaming','🎬'),('Game Topup','game-topup','🎮'),('Akun Premium','akun-premium','⭐'),('Software Digital','software-digital','💻') on conflict(slug) do nothing;
insert into products(category_id,name,slug,price,discount_price,stock,description,benefits,instructions,is_active,is_popular,is_new,is_promo) select c.id,'Canva Business Team 100 Seat','canva-business-team-100-seat',48000,39000,100,'Akses Canva Business Team untuk kebutuhan desain premium.','Akses team, fitur premium, cocok reseller.','Pastikan email aktif untuk invite team.',true,true,true,true from categories c where c.slug='canva-team' on conflict(slug) do nothing;
insert into products(category_id,name,slug,price,stock,description,benefits,instructions,is_active,is_popular,is_new) select c.id,'Leonardo AI Access','leonardo-ai-access',55000,50,'Akses tools AI image generator.','Cocok untuk desain, konten, dan prompt visual.','Ikuti panduan login dari admin.',true,true,true from categories c where c.slug='ai-tools' on conflict(slug) do nothing;
insert into products(category_id,name,slug,price,stock,description,benefits,instructions,is_active,is_new) select c.id,'ChatGPT Plus Sharing','chatgpt-plus-sharing',75000,30,'Akses sharing ChatGPT Plus.','Cepat untuk kerja, belajar, dan konten.','Gunakan sesuai aturan layanan.',true,true from categories c where c.slug='ai-tools' on conflict(slug) do nothing;
insert into products(category_id,name,slug,price,stock,description,benefits,instructions,is_active) select c.id,'Netflix Premium','netflix-premium',45000,40,'Akun streaming premium.','Kualitas HD dan proses cepat.','Jangan ubah password tanpa izin.',true from categories c where c.slug='streaming' on conflict(slug) do nothing;
insert into products(category_id,name,slug,price,stock,description,benefits,instructions,is_active) select c.id,'CapCut Pro','capcut-pro',35000,60,'Akses editing video premium.','Template premium dan fitur pro.','Login sesuai instruksi admin.',true from categories c where c.slug='software-digital' on conflict(slug) do nothing;
insert into products(category_id,name,slug,price,stock,description,benefits,instructions,is_active) select c.id,'Spotify Premium','spotify-premium',30000,70,'Akun musik premium.','Tanpa iklan dan kualitas audio lebih baik.','Data dikirim setelah pembayaran valid.',true from categories c where c.slug='akun-premium' on conflict(slug) do nothing;
insert into testimonials(name,message,rating,is_active) values ('Rani','Proses cepat dan admin responsif.',5,true),('Dika','Produk langsung dikirim setelah pembayaran.',5,true),('Maya','Dashboard rapi dan gampang cek invoice.',5,true) on conflict do nothing;
insert into settings(site_name,whatsapp,email,instagram,tiktok,telegram,bank_info) values ('STOKDIGI','6281234567890','admin@stokdigi.com','https://instagram.com/stokdigi','https://tiktok.com/@stokdigi','https://t.me/stokdigi','BCA 123456789 a/n STOKDIGI');
