# STOKDIGI - Marketplace Produk Digital

Project Next.js + Supabase siap deploy ke Vercel.

## 1. Setup lokal
```bash
npm install
cp .env.example .env.local
npm run dev
```

## 2. Setup Supabase
1. Buat project di Supabase.
2. Buka SQL Editor.
3. Paste isi `supabase/schema.sql` lalu Run.
4. Buka Project Settings > API, ambil URL dan anon key.
5. Masukkan ke `.env.local` atau Environment Variables Vercel.

## 3. Membuat admin pertama
1. Register lewat `/register`.
2. Di Supabase SQL Editor jalankan:
```sql
update profiles set role='admin' where id = (select id from auth.users where email='EMAIL_KAMU');
```
Jika profile belum otomatis muncul, jalankan:
```sql
insert into profiles(id, full_name, role)
select id, email, 'admin' from auth.users where email='EMAIL_KAMU'
on conflict(id) do update set role='admin';
```

## 4. Deploy ke Vercel
1. Upload project ke GitHub.
2. Import repository di Vercel.
3. Tambahkan Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_SITE_URL`
4. Klik Deploy.

## 5. Connect domain
1. Di Vercel buka Project > Settings > Domains.
2. Tambahkan domain kamu.
3. Ikuti instruksi DNS Vercel.
4. Jika pakai Cloudflare, arahkan CNAME `www` ke Vercel dan A record root sesuai instruksi Vercel.

## Catatan penting
- Checkout saat ini manual: QRIS/transfer/e-wallet dan verifikasi admin.
- Upload bukti pembayaran dapat ditambahkan melalui Supabase Storage. Versi ini memakai kolom URL bukti pembayaran agar sederhana dan stabil saat deploy.
- Pastikan produk digital yang dijual legal dan tidak melanggar aturan platform.
