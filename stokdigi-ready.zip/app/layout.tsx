import './globals.css';import type { Metadata } from 'next';
export const metadata: Metadata={title:'STOKDIGI - Marketplace Produk Digital',description:'Marketplace produk digital terpercaya'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body>{children}</body></html>}
